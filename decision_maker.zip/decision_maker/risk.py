def compute_risk(confidence, entropy, ood_score):
    risk = 0

    # Weight 1: Confidence is key
    if confidence >= 0.85: risk += 4
    elif confidence >= 0.70: risk += 2

    # Weight 2: Entropy (Model Certainty)
    # If entropy is low (< 0.3), the model is very sure.
    if entropy <= 0.3: risk += 3
    elif entropy <= 0.5: risk += 1

    # Weight 3: OOD (Out of Distribution)
    # If OOD is high (> 0.7), the model is confused. 
    # We should LOWER the risk score so we don't false-trigger.
    if ood_score > 0.7:
        risk -= 2
    
    return max(0, risk)