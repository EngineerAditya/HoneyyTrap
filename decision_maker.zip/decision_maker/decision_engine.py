from decision_maker.risk import compute_risk
from decision_maker.conversation_type import update_type, aggregate_type, detect_shift
from decision_maker.config import ACTIVATE_THRESHOLD, CLARIFY_THRESHOLD

class DecisionMaker:
    def __init__(self):
        # Thresholds for the GUVI evaluation
        self.ACTIVATE_THRESHOLD = ACTIVATE_THRESHOLD
        self.CLARIFY_THRESHOLD = CLARIFY_THRESHOLD

    def run(self, analysis_json, session_id):
        pclass = analysis_json.get("predicted_class", "normal")
        conf = analysis_json.get("confidence", 0.0)
        ent = analysis_json.get("entropy", 1.0)
        ood = analysis_json.get("ood_score", 0.0)

        # 1. IMMEDIATE PASS for Normal messages
        if pclass == "normal":
            return {
                "action": "ALLOW",
                "risk_score": 0,
                "strategy_shift": False,
                "reason": "Normal conversation detected"
            }

        # 2. Update Conversation History
        update_type(session_id, pclass, conf)
        convo_type, strength = aggregate_type(session_id)
        shifted = detect_shift(session_id)

        # 3. Enhanced Risk Calculation
        risk = compute_risk(conf, ent, ood)
        
        # 4. Improvisation: The "Agentic" Decision
        # If the scammer is shifting tactics (shifted=True), 
        # we boost the risk to trigger the agent immediately.
        if shifted:
            risk += 2

        if risk >= self.ACTIVATE_THRESHOLD:
            action = "ACTIVATE_AGENT"
            reason = f"Confirmed {pclass} pattern."
        elif risk >= self.CLARIFY_THRESHOLD:
            action = "ASK_CLARIFICATION"
            reason = "Suspicious behavior, need more context."
        else:
            action = "MONITOR"
            reason = "Potential scam, observing."

        return {
            "action": action,
            "risk_score": min(risk, 10), # Cap at 10
            "conversation_type": convo_type,
            "type_strength": strength,
            "strategy_shift": shifted,
            "reason": reason
        }